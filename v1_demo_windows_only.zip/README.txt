Please execute the `Reflections.exe` file, which can be found within the 'Release' folder. 

This game is compatible only with the Windows OS!.

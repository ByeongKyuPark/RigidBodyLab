Please run the RigidbodyLab.exe file located in the 'Release' folder.

This demo is an experimental game engine designed to test graphics and physics components. 